#ifndef PyMPI_COMPAT_MPICH2_H
#define PyMPI_COMPAT_MPICH2_H

#if defined(__SICORTEX__)
#include "sicortex.h"
#endif

#endif /* !PyMPI_COMPAT_MPICH2_H */
